import numpy as np
import os
import cv2
from deepface import DeepFace
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_bcrypt import Bcrypt
from flask_wtf import FlaskForm
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from wtforms import StringField, PasswordField, SubmitField, EmailField
from wtforms.validators import DataRequired, Email
from datetime import timedelta
from scipy.stats import entropy
from flask_sqlalchemy import SQLAlchemy
import base64

# --- Configuration de l'application ---
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'  # Nouveau nom de la base de données
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = os.urandom(24)  # Clé secrète aléatoire pour la sécurité
app.permanent_session_lifetime = timedelta(minutes=5)  # Durée de vie de session
app.config['SESSION_COOKIE_SECURE'] = True  # N'envoyer le cookie que sur des connexions HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True  # Empêcher l'accès au cookie par JavaScript
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'  # Protéger contre les attaques CSRF

# Initialisation des bibliothèques de sécurité
bcrypt = Bcrypt(app)
limiter = Limiter(app, key_func=get_remote_address)
db = SQLAlchemy(app)  # Initialisation de SQLAlchemy

# --- Modèle utilisateur ---
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)

# --- Répertoire de sauvegarde des images capturées ---
CAPTURE_DIR = os.path.join('static', 'captured')
if not os.path.exists(CAPTURE_DIR):
    os.makedirs(CAPTURE_DIR)

# Chargement du modèle Haar Cascade pour la détection de visages
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# --- Formulaires ---
class LoginForm(FlaskForm):
    username = StringField('Nom d’utilisateur', validators=[DataRequired()])
    password = PasswordField('Mot de passe', validators=[DataRequired()])
    submit = SubmitField('Se connecter')

class RegistrationForm(FlaskForm):
    username = StringField('Nom d’utilisateur', validators=[DataRequired()])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Mot de passe', validators=[DataRequired()])
    submit = SubmitField('S’inscrire')

# --- Fonctions utilitaires ---
# Détection d'image générée par IA
def detect_ai_generated(image):
    try:
        rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        gray_img = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2GRAY)

        # Analyse du bruit
        noise = cv2.Laplacian(gray_img, cv2.CV_64F).var()

        # Analyse de l'histogramme
        hist = cv2.calcHist([gray_img], [0], None, [256], [0, 256])
        hist_entropy = entropy(hist.flatten())

        # Détection de contours
        edges = cv2.Canny(gray_img, 100, 200)
        edge_percentage = np.count_nonzero(edges) / edges.size

        # Score d'IA
        score = (noise < 100) + (hist_entropy < 5) + (edge_percentage < 0.05)

        is_ai_generated = score >= 2
        confidence = (score / 3) * 100

        return {
            "is_ai_generated": is_ai_generated,
            "confidence": round(confidence, 2),
            "classification": "AI Generated" if is_ai_generated else "Real",
            "details": {
                "noise_level": round(noise, 2),
                "histogram_entropy": round(float(hist_entropy), 2),
                "edge_percentage": round(edge_percentage * 100, 2)
            }
        }
    except Exception as e:
        print(f"Error in AI detection: {str(e)}")
        return {
            "is_ai_generated": None,
            "confidence": 0,
            "classification": "Error in detection",
            "error": str(e)
        }

# Redimensionner une image à une taille donnée
def resize_image(image, size=(224, 224)):
    return cv2.resize(image, size)

# Détection de visages dans une image
def detect_faces(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

# Comparaison des visages entre une image capturée et des images de comparaison
def compare_faces(captured_image, comparison_dir):
    results = []
    seen_files = set()  # Pour éviter les doublons
    faces_captured = detect_faces(captured_image)

    if len(faces_captured) == 0:
        print("Aucun visage détecté dans l'image capturée.")
        return []
    
    for (x, y, w, h) in faces_captured:
        face_captured = captured_image[y:y+h, x:x+w]
        face_captured = resize_image(face_captured)

        for filename in os.listdir(comparison_dir):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                img_path = os.path.join(comparison_dir, filename)
                comparison_image = cv2.imread(img_path)

                if comparison_image is None:
                    print(f"Impossible de lire l'image {filename}.")
                    continue

                faces_comparison = detect_faces(comparison_image)

                if len(faces_comparison) == 0:
                    print(f"Aucun visage détecté dans l'image {filename}.")
                    continue

                for (x_comp, y_comp, w_comp, h_comp) in faces_comparison:
                    face_comparison = comparison_image[y_comp:y_comp+h_comp, x_comp:x_comp+w_comp]
                    face_comparison = resize_image(face_comparison)

                    try:
                        result = DeepFace.verify(face_captured, face_comparison, enforce_detection=False)
                        is_similar = result['verified']

                        if is_similar and filename not in seen_files:
                            results.append({
                                'filename': filename,
                                'compared_image_path': img_path,  # Gardez le chemin de l'image similaire
                                'classification': "Réelle" if not detect_ai_generated(comparison_image)['is_ai_generated'] else "Générée par IA"
                            })
                            seen_files.add(filename)
                    except Exception as e:
                        print(f"Erreur lors de la comparaison avec {filename}: {e}")
                        continue

    return results

# --- Routes Flask ---
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            return render_template('register.html', form=form, error="Ce nom d'utilisateur existe déjà.")

        existing_email = User.query.filter_by(email=form.email.data).first()
        if existing_email:
            return render_template('register.html', form=form, error="Cet email est déjà utilisé.")

        new_user = User(username=form.username.data, email=form.email.data)
        new_user.set_password(form.password.data)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            session['logged_in'] = True
            session['username'] = user.username  # Enregistrer le nom d'utilisateur dans la session
            return redirect(url_for('index'))
        else:
            return render_template('login.html', form=form, error="Identifiants invalides.")

    return render_template('login.html', form=form)

@app.route('/', methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def index():
    if 'logged_in' not in session:
        return redirect(url_for('login'))

    results, ai_results, captured_filename, image_type = None, None, None, None

    if request.method == 'POST':
        cap = cv2.VideoCapture(0)
    
        if not cap.isOpened():
            return render_template('index.html', results="Impossible d'ouvrir la caméra.")

        ret, frame = cap.read()

        if ret:
            captured_filename = os.path.join(CAPTURE_DIR, 'capture.jpg')
            cv2.imwrite(captured_filename, frame)
            cap.release()
            print("Image capturée.")
        else:
            cap.release()
            return render_template('index.html', results="Impossible de capturer l'image.")

        # Analyser l'image capturée
        detected_faces = detect_faces(frame)

        if len(detected_faces) == 0:
            return render_template('index.html', results="Aucun visage détecté.")

        # Comparer avec les images de comparaison
        comparison_dir = os.path.join('static', 'comparison')
        results = compare_faces(frame, comparison_dir)

        # Analyser si l'image capturée est générée par IA
        ai_results = detect_ai_generated(frame)

    return render_template('index.html', results=results, ai_results=ai_results, captured_filename=captured_filename)

@app.route('/upload_image', methods=['POST'])
def upload_image():
    data = request.get_json()
    image_data = data.get('image')

    # Traitez ici l'image reçue
    if image_data:
        # Supprimez le préfixe 'data:image/jpeg;base64,' de l'image
        image_data = image_data.split(',')[1]

        # Décodage de l'image
        image = base64.b64decode(image_data)
        image_path = os.path.join(CAPTURE_DIR, 'capture.jpg')
        
        with open(image_path, 'wb') as f:
            f.write(image)

        return jsonify({"message": "Image téléchargée avec succès"}), 200
    else:
        return jsonify({"message": "Aucune image reçue"}), 400


@app.route('/logout')
def logout():
    session.clear()  # Effacer la session
    return redirect(url_for('login'))

# --- Exécution de l'application ---
if __name__ == '__main__':
    db.create_all()  # Créer les tables de la base de données
    app.run(debug=True)
